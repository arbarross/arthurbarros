from ..en_PH import Provider as EnPhMiscProvider


class Provider(EnPhMiscProvider):
    """No difference from Misc Provider for en_PH locale (yet)"""
