from .. import Provider as PythonProvider  # pragma: no cover


class Provider(PythonProvider):  # pragma: no cover
    pass
