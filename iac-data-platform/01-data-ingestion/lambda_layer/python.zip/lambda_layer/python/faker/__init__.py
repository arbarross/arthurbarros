from faker.factory import Factory
from faker.generator import Generator
from faker.proxy import Faker

VERSION = "13.3.4"

__all__ = ("Factory", "Generator", "Faker")
